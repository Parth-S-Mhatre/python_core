x=int(input("Enter the value of x:"))
y=int(input("Enter the value of y:"))
if x>0:
    print("X is positive")
elif x<0:
    print("X is negative ")
else:
    print("X is zero ")
    
if x<y or x>y:
    print("x is not equal to y")