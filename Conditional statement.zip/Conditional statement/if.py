age=int(input("Enter the age:"))
if age>18:
    print("ELIGIBLE for voting id")
else:
    print("NOT ELIGIBlE for voting id ")