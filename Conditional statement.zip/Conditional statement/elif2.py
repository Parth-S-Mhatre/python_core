marks=int(input("Enter the marks:"))
if marks>90:
    print("You have got A++")
elif marks>=80:
    print("You have got A+")
elif marks>=75:
    print("You have got B")
elif marks>=55:
    print("you have got c")
else:
    print("your have failed")