age=int(input("Enter the age:"))

if age>18:
    print("You are eligible for driving license:")
else:
    print("Not eligible for driving license")