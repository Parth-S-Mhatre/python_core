
n=int(input("Enter the Number:"))# 10

for i in range(1,n+1):
  if i == 5:
    continue
  print(i)                  # jevha 5 var yeu tevha 5 skip hoil anni pudhe chya iteration la jail like 1 2 3 4 6..10
     