# break statement is use if or match conditional statement
n=int(input("Enter the Number:"))# 10
for i in range(1,n):
    print("\n",i)
    if i==5:
        break # jevha loop 5 var yeil tevha program band hoil means aple la 10 pariyant jaicha hota but break 
    # lav ne 5 pariyant gelo
