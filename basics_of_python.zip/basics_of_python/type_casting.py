# for Example tula addition karichi aahe don num chi so you will use input fun() to take input from user
a=input("Enter the first number:")
b=input("Enter the second Number:")
sum=a+b
print("sum of two Number is ",sum) # , is use for printing that var
# for ex tune a chi 4 anni b chi value 1 tak li mag output tr 5 yeila pahije
# but apn type casting ny keli aahe mg string samjhnun join karel a and b la 
# join means like ek string parth aahe anni dursi Jyoti tr join kela parthjyoti hoil
# same hite a+b will give 4+1=41 not 5
#convert karicha asel string to int or any other data type then we use typecasting
#typecasting means data type change karna in short
x=int(input("Enter the first number:"))
y=int(input("Enter the second Number:"))
# syntax var=datatype(input("msg or sentence you want to print"))
sum1=x+y
print("sum of two Number is ",sum1) 