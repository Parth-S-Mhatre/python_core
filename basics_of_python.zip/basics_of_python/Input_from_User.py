#how to take input from user 
#input()function is used to take input from user
# there two way to take input from user
#1.using input() function 
# for example
print("Enter your name:") #in printing we use double quotes because it's string and string means any word or sentence
name=input()
#2 directly using input() function
# syntax-: var=input("msg you want to print in it like Enter the Number:")
name1=input("Enter the name:")
print(name)
print(name1)