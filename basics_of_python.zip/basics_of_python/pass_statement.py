  
for i in range(10):
       if i % 2 == 0:
           pass  # Skip all even numbers 
       else:
           print(i)  # Print odd numbers