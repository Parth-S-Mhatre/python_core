#using while loop
term=int(input("Enter the term:"))# he input gheniya sathi
sum=0 # jar user ne zero tak la tr sum sum zero
i=1 # ha addition karniya sathi 
while i<=term: # jevha  i mhota hoil term peksha tr condition false hoil anni  baher yeu loop medhun 
    sum=sum+i # anni mag print karu sum
    i+=1  # anni zero tak la tr direct zero print hoil because loop chya ata medhech ny jail

print("Sum of n th nature number is",sum)