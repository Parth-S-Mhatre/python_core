a=2# this store integer only means without decimal points(integre)
name="Jyoti"#this store msg or word or statement you want to print(string)
b=2.67#this store decimal number(float Number) 
print(type(a))  # you can check their type also
print(type(name))
print(type(b))